<?php 
require "dbUtil.php";
session_start();
date_default_timezone_set("PRC");
$user=$_SESSION["user"];
if($user==""){
    echo json_encode(array("data"=>"nologin"));
    return;
}
$userId=$user["id"];
$tid=$_POST["tid"];

$time=date("y-m-d h:i:s");
$joinNum=$_POST["joinNum"];
$linktel=$_POST["linktel"];
$sql="  
     insert into t_together_join
     (joinNum,linktel,pubDate,userId,togetherId)
     values
     ('{$joinNum}','{$linktel}','{$time}','{$userId}','{$tid}')
     ";
$result=mysqli_query($conn,$sql);
if($result){
    echo json_encode(array("data"=>"success"));
}
else{
    echo json_encode(array("data"=>"error"));
    
}
?>