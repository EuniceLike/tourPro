<?php
    header("Content-type:text/html;charset=utf-8");
    session_start();
    require 'dbUtil.php';
    $user =$_SESSION["user"];
    $resultArr=Array();
    $sql = "
        select 
            title,(select count(*) from t_comment c where c.tourId=t.id)countNums 
        from 
            t_tour t 
        where t.userId='{$user[id]}'
    ";
    
    
    $result = mysqli_query($conn,$sql);
    while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
         // 删除所有标签  ==>  正则表达式
        //  /<[^>]+>/
        // /[1234]/
        $newStr = preg_replace("/<[^>]+>/","",$row["title"]);

        $tempStr =  mb_substr($newStr,0,4,"utf-8");
        // 截取部分数据
        $row["title"] = $tempStr."...";
        array_push($resultArr,$row);
    }
    echo json_encode(array("code" => "success","data" =>$resultArr));
?>