<?php
	require "dbUtil.php";
	//获取新的nikeName, userImgUrl,password
	session_start();
	$user = $_SESSION['user'];
	date_default_timezone_set("PRC");
	if($user==''){
        echo json_encode(array("data" => "nologin"));  
        return;
    }
	$userId=$user["id"];
	$imgSrc="../img/user.jpeg";
	if($_FILES["imgName"]["name"]!=null){
		$imgname=$_FILES["imgName"]["name"];   //*****.jpg ***.png

		$hzm=substr($imgname,strpos($imgname,"."));
		$imgSrc ="../uploadimg/".time().rand(1000,9999).$hzm;
		move_uploaded_file($_FILES["imgName"]["tmp_name"], $imgSrc);//文件路径
	}
	$imgSrc1=str_replace('../', '', $imgSrc);
	$sql="update t_user 
			set 
				userImgUrl='{$imgSrc1}'   
			where 
				id='{$user[id]}'
		";
	$result=mysqli_query($conn,$sql);
	if($result){
		echo "<script>alert('修改成功!');window.location='../index.html';</script>";
	}
	else{
		echo "<script>alert('修改失败!');window.location='../login.html';</script>";
	}

	$sql="select * from t_user where id='{$user[id]}' ";
	$result=mysqli_query($conn,$sql);
	$user=mysqli_fetch_array($result,MYSQLI_ASSOC);
	$_SESSION['user']=$user;
	// echo json_encode();

?>