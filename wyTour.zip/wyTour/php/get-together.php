<?php
    require 'dbUtil.php';
    session_start();
    $user = $_SESSION['user'];
    $sql = "
        select 
            u.id uid,t.id tid,title,fromCity,toCity,startDate,limitNum,lastDays,coverImg,pubDate
        from
            t_together t
        left join 
            t_user u
        on
            t.userId = u.id
        where 
            u.id=$user[id]
        order by pubDate desc
    ";
    
    
    $result = mysqli_query($conn,$sql);
    
    $resultArr = Array();
    while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
        // 删除所有标签  ==>  正则表达式
        //  /<[^>]+>/
        // /[1234]/
        // $newStr = preg_replace("/<[^>]+>/","",$row["content"]);

        // $tempStr =  mb_substr($newStr,0,80,"utf-8");
        // // 截取部分数据
        // $row["content"] = $tempStr."...";

        array_push($resultArr,$row);
    }   
    echo json_encode(array('code' => "success", "data" => $resultArr ));