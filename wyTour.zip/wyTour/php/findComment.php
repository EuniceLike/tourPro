<?php
require "dbUtil.php";
$tid=$_POST["tid"];
$sql=" 
     select t.id tid,content,PubDate,userId,tourId,nikeName,userTel,userImgUrl
     from t_comment t 
     left join 
     t_user u 
     on t.userId =u.id 
     where 
        t.tourId= '{$tid}'
      order by pubDate desc ";
$result=mysqli_query($conn,$sql);
$resultArr=Array();
while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
  array_push($resultArr,$row);
}
echo json_encode(array('code' => "success" , "data" => $resultArr));
?>