<?php
    require 'dbUtil.php';
    // 记录用户登录状态
    // PHP 的 session   存放一个已经登录的用户信息
    session_start();


    $resultArr = Array();

    $tel = $_REQUEST["tel"];
    $password = $_REQUEST["pass"];

    // 商业开发而言  代码要求严禁 校验是要做的

    // 在业务逻辑上不做校验 不会影响到业务

    // 做一次  用户名是否存在的操作
    

    $sql = "
        select 
            * 
        from 
            t_user 
        where 
            userTel = '{$tel}' and password = '{$password}'
    ";

    $result = mysqli_query($conn,$sql);

    if($result->num_rows == 0){
        $resultArr["code"] = "error";
        $resultArr["msg"] = "用户名或密码错误";
        echo json_encode($resultArr);
        return;
    }

    $user = mysqli_fetch_array($result,MYSQLI_ASSOC);

    $_SESSION["user"] = $user;
    // echo json_encode($_SESSION["user"]['nikeName']);
    $resultArr["code"] = "success";
    $resultArr["msg"] = "登录成功";
    echo json_encode($resultArr);
    return;