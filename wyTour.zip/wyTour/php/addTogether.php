<?php session_start(); ?>
<meta charset="UTF-8">
<?php 
	include "dbUtil.php";
	
    $user = $_SESSION['user'];
    if($user==''){
    	echo "<script>alert('未登录！请登录！！');
    		window.location.href='../login.html';
    	    </script>";
        return;
    }
	date_default_timezone_set("PRC");
	//获取标题，标题类型，内容，获取系统时间
	$userId=$_SESSION["user"]["id"];
	$title=$_POST["tgTitle"];//标题
	$tel=$_POST["tel"];//手机
	$qq=$_POST["QQ"];//QQ
	$wx=$_POST["weixin"];//QQ
	if($tel==0){
		$tel=null;
	}
	if($qq==0){
		$qq=null;
	}
	if($wx==0){
		$wx=null;
	}
	$toCity=$_POST["toCity"];//
	$fromCity=$_POST["fromCity"];//出发城市
	$startDate=$_POST["startDate"];//出发时间
	$lastDays=$_POST["lastDays"];//截止时间
	$limitNum=$_POST["limitNum"];//限制人数
	$info=$_POST["info"];//结伴描述
	$time=date("y-m-d h:i:s");//获取系统时间
	$userId = $user["id"];
	//判断是否上传图片 没上传则加载默认图片

	$imgSrc="../img/bg.jpg";
	if($_FILES["ImgName"]["name"]!=null){
		
		$imgname=$_FILES["ImgName"]["name"];   //*****.jpg ***.png

		$hzm=substr($imgname,strpos($imgname,"."));
		$imgSrc ="../uploadimg/".time().rand(1000,9999).$hzm;
		move_uploaded_file($_FILES["ImgName"]["tmp_name"], $imgSrc);//文件路径
	}
	$imgSrc1=str_replace('../', '', $imgSrc);
		$sql ="insert into t_together
				   (title,tel,qq,weixin,toCity,fromCity,startDate,lastDays,limitNum,intro,coverImg,userId,pubDate)
				values
		           ('{$title}','{$tel}','{$qq}','{$wx}','{$toCity}','{$fromCity}','{$startDate}','{$lastDays}','{$limitNum}','{$info}','{$imgSrc1}','{$userId}','{$time}')
	           ";
    echo $sql;
		$flag = mysqli_query($conn,$sql);	
		if($flag){
			echo "<script>window.location.href='../together.html';</script>";
	    }else{
			echo "<script>alert('添加失败！');</script>";
		}
		