<?php
    require 'dbUtil.php';
    session_start();
    $tid = $_REQUEST['tid'];

    $sql="delete from t_together_join where togetherId = $tid";
    $result = mysqli_query($conn,$sql);

    $sql="delete from t_together where id=$tid";
    $result=mysqli_query($conn,$sql);
    
    if($result){
        echo json_encode(array("data"=>"success"));
    }
    else{
        echo json_encode(array("data"=>"error"));
    }
