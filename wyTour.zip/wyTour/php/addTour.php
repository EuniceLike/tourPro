<?php session_start(); ?>
<meta charset="UTF-8">
<?php 
	include "dbUtil.php";
	
    $user = $_SESSION['user'];
    if($user==''){
    	echo "<script>alert('未登录！请登录！！');
    		window.location.href='../login.html';
    	    </script>";
        return;
    }
	date_default_timezone_set("PRC");
	//获取标题，标题类型，内容，获取系统时间
	$title=$_POST["tourTitle"];//标题
	$type=$_POST["tourType"];//标题类型
	$content=$_POST["tourcontent"];//内容
	$time=date("y-m-d h:i:s");//获取系统时间
	$userId = $user["id"];
	//判断是否上传图片 没上传则加载默认图片

	$imgSrc="../img/bg.jpg";
	if($_FILES["imgName"]["name"]!=null){
		
		$imgname=$_FILES["imgName"]["name"];   //*****.jpg ***.png

		$hzm=substr($imgname,strpos($imgname,"."));
		$imgSrc ="../uploadimg/".time().rand(1000,9999).$hzm;
		move_uploaded_file($_FILES["imgName"]["tmp_name"], $imgSrc);//文件路径
	}
	$imgSrc1=str_replace('../', '', $imgSrc);
		$sql ="insert into t_tour
				   (title,content,contentImg,type,publishDate,userId)
				values
		           ('{$title}','{$content}','{$imgSrc1}','{$type}','{$time}','{$userId}')
	           ";

		$flag = mysqli_query($conn,$sql);	
		if($flag){
			echo "<script>window.location.href='../index.html';</script>";
	    }else{
			echo "<script>alert('添加失败！');</script>";
		}
		