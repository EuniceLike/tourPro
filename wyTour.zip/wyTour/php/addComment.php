<?php 
require "dbUtil.php";
session_start();
date_default_timezone_set("PRC");
$user=$_SESSION["user"];
if($user==""){
    echo json_encode(array("data"=>"nologin"));
    return;
}
$userId=$user["id"];
$content=$_POST["content"];
$tid=$_POST["tid"];
$time=date("y-m-d h:i:s");
$sql="  
     insert into t_comment
     (content,pubDate,userId,tourId)
     values
     ('{$content}','{$time}','{$userId}','{$tid}')
     ";
$result=mysqli_query($conn,$sql);
if($result){
    echo json_encode(array("data"=>"success"));
}
else{
    echo json_encode(array("data"=>"error"));
    
}
?>