<?php
	require "dbUtil.php";
	//获取新的nikeName, userImgUrl,password
	session_start();
	$user = $_SESSION['user'];
	echo json_encode($user);
	if($user==''){
        echo json_encode(array("data" => "nologin"));  
        return;
    }
	
	$newName=$_REQUEST["newname"];
	$resultArr = Array();
    
	echo $newName;
	
	$sql="update t_user 
			set 
				nikeName='{$newName}'  
			where 
				id='{$user[id]}'
		";
	$result=mysqli_query($conn,$sql);

	if($result==0){
		$resultArr["code"] = "error";
		$resultArr["msg"] = "修改失败";
		echo json_encode($resultArr); 
		return;
	}

	$sql="select * from t_user where id='{$user[id]}' ";
	$result=mysqli_query($conn,$sql);
	$user=mysqli_fetch_array($result,MYSQLI_ASSOC);
	$_SESSION['user']=$user;
	// echo json_encode();

?>