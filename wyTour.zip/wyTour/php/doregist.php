<?php
    // 注册新用户
    
    require "dbUtil.php";


    // 向mysql 中写入数据  
    // tel
    $userTel = $_REQUEST["tel"];

    $resultArr = Array();

    if($userTel==""){
       $resultArr["code"] = "error";
       $resultArr["msg"] = "手机号不能为空";
       echo json_encode($resultArr);
       return;
    }

    $selSql = "
        select 
            id,nikeName,userTel,password,userImgUrl
        from 
            t_user 
        where 
            userTel = '{$userTel}'
    ";
    $result = mysqli_query($conn,$selSql);
    // 结果集中有多少条返回数据
    //$result->num_rows
    if($result->num_rows>0){
        $resultArr["code"] = "error";
        $resultArr["msg"] = "手机号已存在";
        echo json_encode($resultArr);
        return;
    }

    // nikeName password userImgUrl
    $nikeName = "乖乖";
    $userImgUrl = "img/user.jpeg";

    // 随机生成数值 （6）
    // rand(开始值|最小值，结束值|最大值)
    $password = rand(100000,999999);

    $sql = "
        insert into t_user 
            (nikeName,userTel,password,userImgUrl)
        values
            ('{$nikeName}','{$userTel}','{$password}','{$userImgUrl}')
    ";

    $result = mysqli_query($conn,$sql);

    $resultArr["code"] = "success";
    $resultArr["msg"] = "注册成功";

    $resultArr["password"] = $password;
    echo json_encode($resultArr);