<?php
    require 'dbUtil.php';

    $sql = "
        select 
            t.id tid, coverImg ,datediff(startDate,now()) mydiff,toCity,intro,userImgUrl,nikeName ,(select count(*) from t_together_join j where j.togetherId=t.id) countNum
        from 
            t_together t 
        left join 
            t_user u 
        on 
            t.userId=u.id
        order by t.id desc


    ";
    
    
    $result = mysqli_query($conn,$sql);
    
    $resultArr = Array();
    while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
        // 删除所有标签  ==>  正则表达式
        //  /<[^>]+>/
        // /[1234]/
        $newStr = preg_replace("/<[^>]+>/","",$row["intro"]);

        $tempStr =  mb_substr($newStr,0,30,"utf-8");
        // 截取部分数据
        $row["intro"] = $tempStr."...";

        array_push($resultArr,$row);
    }
   
    

    
    echo json_encode(array('code' => "success", "data" => $resultArr ));