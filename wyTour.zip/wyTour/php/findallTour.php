<?php
    require 'dbUtil.php';

    $count= $_GET['count'];
    $sql = "
        select 
            t.id tid,title,content,contentImg,type,publishDate,
            nikeName,userImgUrl
        from
            t_tour t
        left join 
            t_user u
        on
            t.userId = u.id
        order by tid desc
        limit 0,$count
    ";
    
    
    $result = mysqli_query($conn,$sql);
    
    $resultArr = Array();
    while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
        // 删除所有标签  ==>  正则表达式
        //  /<[^>]+>/
        // /[1234]/
        $newStr = preg_replace("/<[^>]+>/","",$row["content"]);

        $tempStr =  mb_substr($newStr,0,50,"utf-8");
        // 截取部分数据
        $row["content"] = $tempStr."...";

        array_push($resultArr,$row);
    }
   
    

    
    echo json_encode(array('code' => "success", "data" => $resultArr ));