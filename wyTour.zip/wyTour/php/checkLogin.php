<?php
    // 校验用户是否登录
    session_start();
    $user = $_SESSION["user"];

    // print_r($user);

    $resultArr = Array();

    if($user==""){
        $resultArr["status"] = false;
        // $resultArr["user"] = "";
        echo json_encode($resultArr);
        return;
    }
    $resultArr["status"] = true;
    $resultArr["user"] = $user;
    echo json_encode($resultArr);

    // echo json_encode($user["nikeName"]);
    return;