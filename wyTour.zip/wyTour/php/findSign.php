<?php
require "dbUtil.php";
$tid=$_POST["tid"];
$sql=" 
     select t.id tid,PubDate,userId,togetherId,nikeName,linktel,joinNum,userImgUrl
     from 
     	t_together_join t 
     left join 
     	t_user u 
     on 
     	t.userId =u.id 
     where 
        t.togetherId= '{$tid}'
     and joinNum>=1
      order by pubDate desc "
    ;
$result=mysqli_query($conn,$sql);
$resultArr=Array();
while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
  array_push($resultArr,$row);
}
echo json_encode(array('code' => "success" , "data" => $resultArr));

?>
