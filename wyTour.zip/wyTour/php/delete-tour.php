<?php
    require 'dbUtil.php';
    session_start();
    $tid = $_REQUEST['tid'];

    $sql="delete from t_comment where tourId = $tid";//
    $result=mysqli_query($conn,$sql);

    $sql="delete from t_tour where id = $tid ";
    $result=mysqli_query($conn,$sql);

    if($result){
        echo json_encode(array("data"=>"success"));
    }
    else{
        echo json_encode(array("data"=>"error"));
    }
    