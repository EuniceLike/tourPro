$(function(){

        $("#addComment").click(function () {
            $.ajax({
                type: "POST",
                url: "php/addComment.php",
                dataType: "json",
                data: {
                	
                  content:$("#content").val(),
                  tid:<?php echo $tid ?>
                },
                success:function(data){
                  if(data.data=="success"){
                
                      findComment();

                  }
                  else if(data.data=="nologin"){
                     alert("您还未登录！");
                  }

                }
             })
           
        })  
        function findComment(){
            $.ajax({
                type: "POST",
                url: "php/findCommentByid.php",
                dataType: "json",
                data: {
                  tid:<?php echo $tid ?>
                }, 
                success:function(data){
                    console.log(data.data);
                    var str = template("test", {
                    Data: data.data
                }); 
                $("#mycontent").html(str);
                }
            })
         }
        findComment();


     })