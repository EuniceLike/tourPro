$(function(){
	// $("#together").click(function(){
	// 	$.ajax({
	// 		type:"POST",
	// 		url:"php/addTogether.php",
	// 		data:{
	// 			tgTitle:$("#titi").val(),
	// 			tel:$("#tel").val(),
	// 			QQ:$("#qq").val(),
	// 			weixin:$("#weixin").val(),
	// 			toCity:$("#toCity").val(),
	// 			fromCity:$("#fromCity").val(),
	// 			startDate:$("#startDate").val(),
	// 			lastDays:$("#lastDays").val(),
	// 			limitNum:$("#limitNum").val(),
	// 			info:$("#info").val(),
	// 			ImgName:$("#fileTo").val(),
	// 		},
	// 		dataType:"json",
	// 		success:function(data){
	// 			console.log(data.data);
				
	// 		}
	// 	})
	// });
});
function openFile(obj){
	console.log(111);
	$("#fileTo").click();
}
function changeFile(obj){
	console.log($(obj));
	var imgUrl=window.URL.createObjectURL(obj.files[0]);
	$("#showImg").attr("src",imgUrl);
}