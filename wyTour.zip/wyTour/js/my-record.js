$(function(){
		$("#myTrip").css('display','block');
		$("#trip").css('color','white').css('background','#ffa800');
		$("#showTri").click(function(){
			$("#myFriend").css('display','none');
			$("#myTrip").css('display','block');
			$("#myCount").css('display','none');
			$("#friend").css('color','gray');
			$("#friend").css('background','none');
			$("#trip").css('color','white');
			$("#trip").css('background','#ffa800');
			$("#count").css('color','gray');
			$("#count").css('background','none');			
		});
		$("#showFri").click(function(){
			$("#myFriend").css('display','block');
			$("#myTrip").css('display','none');
			$("#myCount").css('display','none');
			$("#friend").css('color','white');
			$("#friend").css('background','#ffa800');
			$("#trip").css('color','gray');
			$("#trip").css('background','none');
			$("#count").css('color','gray');
			$("#count").css('background','none');
				
		});
		$("#showCount").click(function(){
			$("#myFriend").css('display','none');
			$("#myTrip").css('display','none');
			$("#myCount").css('display','block');
			$("#count").css('color','white');
			$("#count").css('background','#ffa800');
			$("#trip").css('color','gray');
			$("#trip").css('background','none');
			$("#friend").css('color','gray');
			$("#friend").css('background','none');
				
		});
		//echarts表
	 // 基于准备好的dom，初始化echarts实例
    var myChart = echarts.init(document.getElementById('main'));

    // 指定图表的配置项和数据
    var option = {
    	color: ['#ffa800'],
        tooltip : {
	        trigger: 'axis',
	        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
	            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
	        }
	    },
	    grid: {
	        left: '3%',
	        right: '20%',
	        bottom: '3%',
	        containLabel: true,

	    },
	    xAxis : [
	        {
	            name:'游记的标题',
	            type : 'category',
	            data : (function(){
	            	var arr=[];
	            	$.ajax({
	            		type:"POST",
	            		async:false,//同步执行
	            		url:"php/echart.php",
	            		dataType:"json",
	            		success:function(result){
	            			if(result){
	            				for(var i=0;i<result.data.length;i++){
	            					arr.push(result.data[i].title);
	            				}
	            			}
	            		},
	            		error:function(errorMsg){
	            			alert("请求数据失败");
	            			myChart.hideLoading();
	            		}
	            	})
	            	return arr;
	            })(),
	            axisTick: {
	                alignWithLabel: true
	            },
	            
	            axisLabel:{
	            	interval:0,//横坐标信息全部显示

	            },
	        }
	    ],
	    yAxis : [
	        {
	        	name:'评论数量',
	            type : 'value',
	        }
	    ],
	    series : [
	        {
	            name:'直接访问',
	            type:'bar',
	            barWidth: '60%',
	            data : (function(){
	            	var arr=[];
	            	$.ajax({
	            		type:"POST",
	            		async:false,//同步执行
	            		url:"php/echart.php",
	            		dataType:"json",
	            		success:function(result){
	            			if(result){
	            				for(var i=0;i<result.data.length;i++){
	            					console.log(result.data[i].countNums);
	            					arr.push(result.data[i].countNums);
	            				}
	            				console.log(arr);
	            			}
	            		},
	            		error:function(errorMsg){
	            			alert("请求数据失败");
	            			myChart.hideLoading();
	            		}
	            	})
	            	return arr;
	            })(),
	        }
	    ]
    };

    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option);



});
	
	