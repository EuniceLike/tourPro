$(function(){

	cc();
	function cc(){
		$.ajax({
			type:"POST",
			url:"php/checkLogin.php",
			dataType: "json",
			success:function(data){
				console.log(data.status);
				if(data.status==true){
				  	console.log(data.user.nikeName);
				  	$("#regi").css('display','none');
				  	$("#logi").css('display','none');

				  	$("#name").html(data.user.nikeName).css('color','#ffa800').css('lineHeight','60px');
				  	$("#uHeader").attr('src',data.user.userImgUrl);
					// $("#uHeader").src(data.userImgUrl);
				}


			}

		})
	}	
	
});