$(function(){
	
});
function openFile(obj){
	console.log(111);
	$("#fileTo").click();
}
function changeFile(obj){
	console.log($(obj));
	var imgUrl=window.URL.createObjectURL(obj.files[0]);
	$("#showImg").css("backgroundImage","url("+imgUrl+")");
}