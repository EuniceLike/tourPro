$(function(){
	$(".changeLi").mouseover(function(){
		$(this).find('.more').css("background-position"," -80px -80px")
	});

	$(".changeLi").mouseout(function(){
		$(this).find('.more').css("background-position"," 0 -80px")
	});
});