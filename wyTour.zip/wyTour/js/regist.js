$(function(){
	$("#doRegist").click(function(){
		var params={
			tel:$("#tel").val()
		}
		$.ajax({
			type:"POST",
			url:"../php/doregist.php",
			data:params,
			dataType: "json",
			success:function(data){
				if(data.code=='success'){
				   $("#info").html('您的初始密码为：'+data.password);
				    
				}else{
				   console.log(data.msg);
				   $("#info").html(data.msg).addClass('infoRegist');
				   // $("#info").html(data.msg).css("color",'red');
				}


			}

		});
	});

});