$(function(){
	$("#doLogin").click(function(){
		var params={
			tel:$("#tel").val(),
			pwd:$("#pwd").val()
		}
		$.ajax({
			type:"POST",
			url:"DB/util/dologin.php",
			data:params,
			dataType: "json",
			success:function(data){
				if(data.code=='success'){
				   window.location.href="index.html";
				    
				}else{
				   
				   $("#info").html(data.msg).addClass('infoRegist');
				   // $("#info").html(data.msg).css("color",'red');
				}


			}

		})
	})

})