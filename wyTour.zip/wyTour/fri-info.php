<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>结伴详情</title>
<link rel="stylesheet" href="css/index.css">
<link rel="stylesheet" href="css/fri-info.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="icon/iconfont.css">
<link rel="stylesheet" href="css/swiper.css">
<script src="jquery/jquery-1.10.1.min.js" type="text/javascript" ></script>
<script src="jquery/swiper.jquery.js"></script>
<script src="js/bootstrap.js" ></script>
<script src="js/swiper.js"></script>
<script src="js/index.js"></script>
<script src="js/template.js"></script>
</head>
<?php
    
    require 'php/dbUtil.php';

    $tid = $_GET["tid"];

    $sql = "
        select t.id tid, coverImg ,datediff(startDate,now()) mydiff,toCity,intro,userImgUrl,nikeName,fromCity,startDate,lastDays,limitNum ,title
        from 
        	t_together t 
        left join 
        	t_user u 
        on 
        	t.userId=u.id
        where 
            t.id = '{$tid}'
    ";
    $result = mysqli_query($conn,$sql);

    $tour = mysqli_fetch_array($result,MYSQLI_ASSOC);

?>
<?php

	$sql=" 
	     select count(j.togetherId) con,
	     	t.limitNum m
	     from 
	     	t_together_join j
	     left join 
        	t_together t
         on 
        	j.togetherId=t.id
         where 
            t.id = '{$tid}'
	      "
	    ;
	$result1=mysqli_query($conn,$sql);

	$row = mysqli_fetch_array($result1,MYSQLI_ASSOC);
	
?>
<script>
$(function(){

    $("#addSign").click(function () {
    	console.log(111);
        $.ajax({
            type: "POST",
            url: "php/addSign.php",
            dataType: "json",
            data: {
            	joinNum:$("#number").val(),
            	linktel:$("#linktel").val(),
		        tid:<?php echo $tid ?>
            },
            success:function(data){
              if(data.data=="success"){
            		// console.log(data)
                  findComment();

              }
              else if(data.data=="nologin"){
                 alert("您还未登录！");
              }

            }
         })
       
    }); 
    function findComment(){
        $.ajax({
            type: "POST",
            url: "php/findSign.php",
            dataType: "json",
            data: {
              tid:<?php echo $tid ?>
            }, 
            success:function(data){
                console.log(data.data.length);//3
                var str = template("test", {
                Data: data.data
            }); 
            $("#content").html(str);
            }
        })
     }
    findComment();

});
</script>
<style>
.jumbotron{
	background:url(<?php echo $tour['coverImg']; ?>) no-repeat 100% 100%/100% 100%;
	background-size: cover;
 	height:290px;
}
</style>
<script id="test" type="text/html">
	
	{{each Data as val key}}	
	<li>
		<img src="{{val.userImgUrl}}">{{val.nikeName}}
	</li>
	{{/each}}
</script>
<body>
	<nav class="navbar navbar-default navbar-fixed-top">
  		<div class="container head">
    <!-- Brand and toggle get grouped for better mobile display -->
    		<div class="navbar-header">
      			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
	        		<span class="sr-only">Toggle navigation</span>
	        		<span class="icon-bar"></span>
	        		<span class="icon-bar"></span>
	       			<span class="icon-bar"></span>
      			</button>
      			<a class="navbar-brand logo" href="#"></a>
    		</div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      			<ul class="nav navbar-nav">
        			<li><a href="index.html">游记</a></li>
        			<li><a href="together.html">结伴而行</a></li>
        			<li class="dropdown">
          				<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">预留链接<span class="caret"></span></a>
          				<ul class="dropdown-menu">
				            <li><a href="#">Action</a></li>
				            <li><a href="#">Another action</a></li>
				            <li><a href="#">Something else here</a></li>
				            <li role="separator" class="divider"></li>
				            <li><a href="#">Separated link</a></li>
				            <li role="separator" class="divider"></li>
				            <li><a href="#">One more separated link</a></li>
          				</ul>
        			</li>
      			</ul>
      			<ul class="nav navbar-nav navbar-right">
        			<li id="regi"><a href="login.html">登陆</a></li>
        			<li id="logi"><a href="register.html">注册</a></li>
        			<li class="dropdown header" >
         				<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> 
         				<img src="img/user.jpeg" id="uHeader"><span class="caret"></span></a>
          				<ul class="dropdown-menu user">
				            <li ><a class="icon iconfont icon-write" href="send.html"><span>发布游记</span></a></li>
				            <li><a class="icon iconfont icon-write" href="publish.html"><span>发布结伴</span></a></li>
				            <li><a class="icon iconfont icon-write" href="my-record.php"><span>我的发布</span></a></li>
				            <li role="separator" class="divider"></li>
				            <li><a class="icon iconfont icon-set" href="set-header.html"><span>设置</span></a></li>
				            <li><a class="icon iconfont icon-exit" href="php/exit.php"><span>退出</span></a></li>
				        </ul>
       				</li>
       				<li id="name"></li>
     			</ul>
    		</div><!-- /.navbar-collapse -->
  		</div><!-- /.container-fluid -->
	</nav>
	
	<!--巨幕-->
	<div class="jumbotron" id="bg">
		<div class="container">
			<h2><?php echo $tour["title"]; ?></h2>
		</div>
	</div>
	
	<!--主体内容-->
	<div id="cont">
		<div class="left">
			<h3><?php echo $tour["title"]; ?></h3>
			<div class="line"></div>
			<div class="abstract">
				<p>出发地：<?php echo $tour["fromCity"]; ?></p>
				<p>出发时间：<?php echo $tour["startDate"]; ?></p>
				<p>目的地：<?php echo $tour["toCity"]; ?></p>
				<p>大约：<?php echo $tour["lastDays"]; ?>天</p>
				<p>希望人数：<?php echo $tour["limitNum"]; ?>人</p>
				<p>发布人：&nbsp;<img src="<?php echo $tour['userImgUrl']; ?>">&nbsp;<span><?php echo $tour["nikeName"]; ?></span></p>
			</div>
			<h3>结伴描述</h3>
			<div class="line"></div>
			<div class="details">
				<p><?php echo $tour["intro"]; ?></p>
			</div>
			<h3>我要报名</h3>
			<div class="line"></div>
			<form class="form-horizontal">
			  	<div class="form-group">
			    	<label for="number" class="col-sm-2 control-label">结伴人数</label>
			    	<div class="col-sm-10">
			      		<input type="text" class="form-control" id="number" name="joinNum">
			    	</div>
			  	</div>
			  	<div class="form-group">
			    	<label for="number" class="col-sm-2 control-label">联系电话</label>
			    	<div class="col-sm-10">
			      		<input type="text" class="form-control" id="linktel" name="linktel">
			    	</div>
			  	</div>
			  	<div class="form-group">
			    	<label for="number" class="col-sm-2 control-label">同行人数</label>
			    	<div class="col-sm-4">
			      		<input type="text" class="form-control">
			    	</div><span>男/人</span>
			    	
			    	<div class="col-sm-4">
			      		<input type="text" class="form-control">
			    	</div><span>女/人</span>

			  	</div>
			  	<div class="form-group">		
			      		<button type="button" class="btn btn-warning" id="addSign">报名</button>
			  	</div>
			</form>
			
		</div>
		<div class="right">
			<div class="nn-bg">
				<p><span id="num"><?php echo $row['con']; ?></span>
				人报名</p>
			</div>
		
			<ul id='content'>
				
			</ul>
			
		</div>
	</div>

	<!--底部-->
	<div class="foot"><p>版权所有：^Eunice^  &nbsp; &nbsp; BY:like1230</p></div>








</body>
</html>
