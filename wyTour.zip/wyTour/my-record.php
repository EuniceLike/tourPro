 <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>游记详情</title>
<link rel="stylesheet" href="css/index.css">
<link rel="stylesheet" href="css/set-header.css">
<link rel="stylesheet" href="css/my-record.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="icon/iconfont.css">
<link rel="stylesheet" href="css/swiper.css">
<script src="jquery/jquery-1.10.1.min.js" type="text/javascript" ></script>
<script src="js/echarts.min.js"></script>
<script src="jquery/swiper.jquery.js"></script>
<script src="js/bootstrap.js" ></script>
<script src="js/swiper.js"></script>
<script src="js/index.js"></script>
<script src="js/my-record.js"></script>
<script src="js/template.js"></script>
</head>
<script>
	$(function(){
		function show(){
			$.ajax({
				type:"GET",
				url:"php/get-tour.php", 
				dataType:"json",
				success:function(data){
					console.log(data.data);
					var str=template("test",{
						Data:data.data
					});
					$("#content2").html(str);
				}
			})
		}
		show();
	});
	function showTri(){
			$.ajax({
				type:"GET",
				url:"php/get-tour.php", 
				dataType:"json",
				success:function(data){
					console.log(data.data);
					var str=template("test",{
						Data:data.data
					});
					$("#content2").html(str);
				}
			})
		}
	showTri();
	function remove1(tid){
		$.ajax({
			type:"GET",
			url:"php/delete-tour.php", 
			data:{
				tid:tid
			},
			dataType:"json",
			success:function(data){
				console.log(data);
				showTri();
			}
		})
	};

	function showFri(){
		$.ajax({
			type:"GET",
			url:"php/get-together.php", 
			dataType:"json",
			success:function(data){
				console.log(data.data);
				var str=template("test1",{
					Data:data.data
				});
				$("#content3").html(str);
			}
		})
	};
	showFri();
	function remove2(tid){
		$.ajax({
			type:"GET",
			url:"php/delete-together.php", 
			data:{
				tid:tid
			},
			dataType:"json",
			success:function(data){
				console.log(data);
				showFri();
			}
		})
	};

</script>
<script id="test" type="text/html">
	{{each Data as val key}}
	<div class="row row1">
		<div class="col-md-3">
			<img src="{{val.contentImg}}">
		</div>
		<div class="col-md-9">
			<p class="p1">{{val.title}}</p>
			<button type="button" class="btn btn-warning revise">修改</button>
			<button type="button" class="btn btn-warning delete" onclick="remove1({{val.tid}})">删除</button>
		</div>
	</div>
	
	{{/each}}
</script>
<script id="test1" type="text/html">
	{{each Data as val key}}
	<div class="row row1">
		<div class="col-md-3">
			<img src="{{val.coverImg}}">
		</div>
		<div class="col-md-9">
			<p class="p1">{{val.title}}</p>
			<p class="p2">
				<span>出发地</span>：{{val.fromCity}} &nbsp;
				<span>出发时间</span>:{{val.startDate}} &nbsp;
				<span>目的地</span>：{{val.toCity}}  &nbsp;
				<span>大约</span>：{{val.lastDays}}天 &nbsp;
				<span>希望人数</span>：{{val.limitNum}}人
			</p>
			<button type="button" class="btn btn-warning revise" >修改</button>
			<button type="button" class="btn btn-warning delete" onclick="remove2({{val.tid}})">删除</button>
		</div>
	</div>
	
	{{/each}}
</script>
<body>
	<nav class="navbar navbar-default navbar-fixed-top">
  		<div class="container head">
    <!-- Brand and toggle get grouped for better mobile display -->
    		<div class="navbar-header">
      			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
	        		<span class="sr-only">Toggle navigation</span>
	        		<span class="icon-bar"></span>
	        		<span class="icon-bar"></span>
	       			<span class="icon-bar"></span>
      			</button>
      			<a class="navbar-brand logo" href="#"></a>
    		</div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      			<ul class="nav navbar-nav">
        			<li><a href="index.html">游记</a></li>
        			<li><a href="together.html">结伴而行</a></li>
        			<li class="dropdown">
          				<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">预留链接<span class="caret"></span></a>
          				<ul class="dropdown-menu">
				            <li><a href="#">Action</a></li>
				            <li><a href="#">Another action</a></li>
				            <li><a href="#">Something else here</a></li>
				            <li role="separator" class="divider"></li>
				            <li><a href="#">Separated link</a></li>
				            <li role="separator" class="divider"></li>
				            <li><a href="#">One more separated link</a></li>
          				</ul>
        			</li>
      			</ul>
      			<ul class="nav navbar-nav navbar-right">
        			<li id="regi"><a href="login.html">登陆</a></li>
        			<li id="logi"><a href="register.html">注册</a></li>
        			<li class="dropdown header" >
         				<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> 
         				<img src="img/user.jpeg" id="uHeader"><span class="caret"></span></a>
          				<ul class="dropdown-menu user">
				            <li ><a class="icon iconfont icon-write" href="send.html"><span>发布游记</span></a></li>
				            <li><a class="icon iconfont icon-write" href="publish.html"><span>发布结伴</span></a></li>
				            <li><a class="icon iconfont icon-write" href="my-record.php"><span>我的发布</span></a></li>
				            <li role="separator" class="divider"></li>
				            <li><a class="icon iconfont icon-set" href="set-header.html"><span>设置</span></a></li>
				            <li><a class="icon iconfont icon-exit" href="php/exit.php"><span>退出</span></a></li>
				        </ul>
       				</li>
       				<li id="name"></li>
     			</ul>
    		</div><!-- /.navbar-collapse -->
  		</div><!-- /.container-fluid -->
	</nav>
    
    <!--主体-->
	<div class="cont2">
		<div class="left">
			<div id="trip">
				<i class="icon iconfont icon-header head"></i>
				<span id="showTri" onclick="showTri()">我的游记</span>
			</div>
			<div id="friend">
				<i class="icon iconfont icon-camera"></i>
				<span id="showFri" onclick="showFri()">我的结伴</span>
			</div>
			<div id="count">
				 <i class="icon iconfont icon-password"></i>
				<span id="showCount">发布统计</span>
			</div>
		</div>
		<div class="right">
		    <!--我的游记-->
			<div id="myTrip">
				<div class="tp">我的游记</div>
				<div id="content2"></div>
			</div>

			<!--我的结伴-->
			<div id="myFriend">
				<div class="tp">我的结伴</div>
				<div id="content3"></div>
		
			</div>

			<div id="myCount">
				<div class="tp">我的结伴</div>
				<div id="main" style="width: 800px;height:520px;"></div>
			</div>



			
		</div>
	</div>



</body>
</html>